#!/bin/bash

wget http://www.mediafire.com/file/ropayv77vklvf56/openpose_coco.npy
wget http://www.mediafire.com/file/7e73ddj31rzw6qq/openpose_vgg16.npy
